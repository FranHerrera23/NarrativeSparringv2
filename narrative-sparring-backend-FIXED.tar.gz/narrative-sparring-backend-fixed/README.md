# Narrative Sparring Backend

## Files to upload to GitHub:

```
narrative-sparring-backend/
├── api/
│   ├── gumroad-webhook.js
│   └── upload-handler.js
└── package.json
```

## After uploading to GitHub:

1. Connect to Vercel
2. Deploy
3. Add environment variables in Vercel dashboard

That's it.
